import { Request, Response, NextFunction } from 'express';
import { supabase } from '../services/supabase';
export async function requireAdmin(req: Request,res: Response,next: NextFunction) {
  const token = req.headers.authorization?.split(' ')[1];
  if(!token) return res.status(401).json({error:'Missing token'});
  const { data:user, error } = await supabase.auth.getUser(token);
  if(error || !user) return res.status(401).json({error:'Invalid token'});
  if(user.user_metadata?.role!=='admin') return res.status(403).json({error:'Admin only'});
  (req as any).user = user;
  next();
}
